import os
import sys
import subprocess
import shutil
import venv
from pathlib import Path

def build_pilot():
    print("=" * 60)
    print("[BUILD] Building QIntellect AI Pilot Executable (Clean Environment)...")
    print("=" * 60)

    base_dir = Path(__file__).parent
    venv_dir = base_dir / "pilot_env"

    # Step 1: Create a clean virtual environment
    if not venv_dir.exists():
        print("[*] Creating a fresh virtual environment (pilot_env)...")
        venv.create(venv_dir, with_pip=True)
    else:
        print("[*] Virtual environment 'pilot_env' already exists. Using it.")

    # Determine paths based on OS
    if os.name == 'nt':
        venv_python = venv_dir / "Scripts" / "python.exe"
        venv_pyinstaller = venv_dir / "Scripts" / "pyinstaller.exe"
    else:
        venv_python = venv_dir / "bin" / "python"
        venv_pyinstaller = venv_dir / "bin" / "pyinstaller"

    # Step 2: Install dependencies into the fresh venv
    print("\n[*] Installing dependencies from requirements.txt... (This may take a minute)")
    subprocess.check_call([str(venv_python), "-m", "pip", "install", "-r", "requirements.txt"], cwd=base_dir)

    print("\n[*] Applying NumPy 1.x fix for Ultralytics/OpenCV compatibility...")
    subprocess.check_call([str(venv_python), "-m", "pip", "install", "numpy<2.0.0"], cwd=base_dir)

    print("\n[*] Installing PyInstaller...")
    subprocess.check_call([str(venv_python), "-m", "pip", "install", "pyinstaller"], cwd=base_dir)

    # Step 3: Run PyInstaller from within the clean venv
    command = [
        str(venv_pyinstaller),
        "--name", "QIntellect_Server",
        "--onedir",
        "--clean",
        "--noconfirm",
        "--add-data", f"templates{os.pathsep}templates",
        "--add-data", f"static{os.pathsep}static",
        "--add-data", f"face_processor.py{os.pathsep}.",
        "--add-data", f"database.py{os.pathsep}.",
        "--add-data", f"config.py{os.pathsep}.",
        "--add-data", f"logger_config.py{os.pathsep}.",
        "--add-data", f"download_models.py{os.pathsep}.",
        "--collect-data", "insightface",
        "pilot_app.py"
    ]

    print("\n[*] Running PyInstaller compilation...")
    print(" ".join(command))
    subprocess.check_call(command, cwd=base_dir)

    print("\n[*] Build successful! Preparing deployment folder...")
    
    dist_dir = base_dir / "dist" / "QIntellect_Server"
    
    # Step 4: Create required external folders in the dist directory
    (dist_dir / "models").mkdir(exist_ok=True)
    (dist_dir / "static" / "profile_photos").mkdir(parents=True, exist_ok=True)
    
    # Step 5: Copy required external assets
    if (base_dir / "attendance.db").exists():
        shutil.copy2(base_dir / "attendance.db", dist_dir / "attendance.db")
        print(" Copied attendance.db to deployment folder.")
    else:
        print("! Warning: attendance.db not found. The app will create a blank one on startup.")

    if (base_dir / "yolov8n.pt").exists():
        shutil.copy2(base_dir / "yolov8n.pt", dist_dir / "yolov8n.pt")
        print(" Copied yolov8n.pt to deployment folder (no download needed by client).")
    else:
        print("! Warning: yolov8n.pt not found in project root. Client may try to download it.")

    if (base_dir / "models").exists():
        # Copy entire models folder recursively (includes buffalo_l subdirectory)
        models_dest = dist_dir / "models"
        if models_dest.exists():
            shutil.rmtree(models_dest)
        shutil.copytree(base_dir / "models", models_dest)
        print(" Copied models/ folder (InsightFace buffalo_l included) to deployment folder.")

    if (base_dir / "static" / "profile_photos").exists():
        photos_dest = dist_dir / "static" / "profile_photos"
        photos_dest.mkdir(parents=True, exist_ok=True)
        for f in (base_dir / "static" / "profile_photos").iterdir():
            if f.is_file():
                shutil.copy2(f, photos_dest / f.name)
        print(" Copied profile photos to deployment folder.")

    print("\n[NOTE] client_config.json will be created fresh on the client machine")
    print("       The setup wizard will appear on first launch to collect NVR/DVR URLs.")

    print("=" * 60)
    print("[DONE] PILOT BUILD COMPLETE!")
    print(f"Your optimized deployment folder is ready at: {dist_dir}")
    print("You can zip the 'QIntellect_Server' folder inside 'dist' and send it to your client!")
    print("="*60)

if __name__ == "__main__":
    build_pilot()
